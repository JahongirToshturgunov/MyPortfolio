from django.shortcuts import redirect, render
from django.views.generic.edit import CreateView
from .models import Contact
from .forms import ContactForm
from telepot import Bot
bot = Bot('5227533717:AAGGev58UZXWL7bZXlwizBFRDmoAejB2yes')
myId = '715975144'

# Create your views here.
class HomeView(CreateView):
    model = Contact
    fields = '__all__'
    template_name = 'profileapp/index.html'
    # return render(request, 'profileapp/index.html')
    success_url = '/'

    def send_bot(self):
        message = f"""
            name: {self.form.name}
            phone: {self.form.email}
            DEFAULT: DEFAULT
        """
        print(message)
        bot.sendMessage(715975144, 'defualt: default')

def homeView(request):
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            message = f"""
                DEFAULT: DEFAULT
            """
            print(message)
            bot.sendMessage(715975144, 'defualt: default')
            form.save()
            return redirect('/')
    else:
        form = ContactForm()
    return render(request, 'profileapp/index.html', {'form': form})

    # if request.GET:
    #     # bot.send_message(myId, f"Portfolio \n {request.GET['name']} {request.GET['email']} \n comment: {request.GET['message']}")
    #     print(f"Portfolio \n {request.GET['name']} {request.GET['email']} \n comment: {request.GET['message']}")
    #     return redirect('/') 
    return render(request, 'profileapp/index.html')    


def loginuser(request):
    info = {
        "apple": "green",
        "banana": "yellow",
        "cherry": "red"
    }
    return render(request, 'governanceandcontrol/login.html', info)
